import { Router } from "express";
import { db } from "../db";

const router = Router();

router.post("/", async (req, res) => {
  const { userId, caption, postType, images } = req.body;

  const post = await db.query(
    "INSERT INTO posts (user_id, caption, post_type) VALUES ($1,$2,$3) RETURNING *",
    [userId, caption, postType]
  );

  for (const img of images) {
    await db.query(
      "INSERT INTO post_images (post_id, image_url) VALUES ($1,$2)",
      [post.rows[0].id, img]
    );
  }

  res.json(post.rows[0]);
});

router.get("/", async (req, res) => {
  const posts = await db.query(`
    SELECT p.*, u.username,
    (SELECT COUNT(*) FROM likes WHERE post_id=p.id) AS like_count
    FROM posts p
    JOIN users u ON u.id = p.user_id
    ORDER BY p.created_at DESC
    LIMIT 50
  `);

  res.json(posts.rows);
});

router.post("/:id/like", async (req, res) => {
  const { userId } = req.body;

  await db.query(
    "INSERT INTO likes (user_id, post_id) VALUES ($1,$2) ON CONFLICT DO NOTHING",
    [userId, req.params.id]
  );

  res.json({ success: true });
});

router.post("/:id/comment", async (req, res) => {
  const { userId, content } = req.body;

  await db.query(
    "INSERT INTO comments (user_id, post_id, content) VALUES ($1,$2,$3)",
    [userId, req.params.id, content]
  );

  res.json({ success: true });
});

export default router;