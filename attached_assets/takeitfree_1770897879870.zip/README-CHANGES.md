Social Community Upgrade Files

Added:
- server/routes/posts.ts
- client/src/pages/Feed.tsx
- client/src/components/CreatePost.tsx

Also remember to register route in server/index.ts:

import postRoutes from "./routes/posts";
app.use("/api/posts", postRoutes);

And add Feed route in client App.tsx:
<Route path="/feed" element={<Feed />} />
