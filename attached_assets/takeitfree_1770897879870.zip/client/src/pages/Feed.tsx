import { useEffect, useState } from "react";

export default function Feed() {
  const [posts, setPosts] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/posts")
      .then(res => res.json())
      .then(setPosts);
  }, []);

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-6">
      {posts.map(post => (
        <div key={post.id} className="bg-white shadow rounded-lg p-4">
          <div className="font-bold">{post.username}</div>
          <div className="text-sm text-gray-600">{post.post_type}</div>
          <div className="my-2">{post.caption}</div>
          <div className="text-sm text-gray-500">❤️ {post.like_count}</div>
        </div>
      ))}
    </div>
  );
}