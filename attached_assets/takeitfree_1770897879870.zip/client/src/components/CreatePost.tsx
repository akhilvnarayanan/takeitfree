import { useState } from "react";

export default function CreatePost() {
  const [caption, setCaption] = useState("");

  const handleSubmit = async () => {
    await fetch("/api/posts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: "USER_ID_HERE",
        caption,
        postType: "community",
        images: []
      })
    });

    setCaption("");
  };

  return (
    <div className="p-4">
      <textarea
        value={caption}
        onChange={e => setCaption(e.target.value)}
        className="w-full border p-2 rounded"
        placeholder="Share something..."
      />
      <button
        onClick={handleSubmit}
        className="bg-blue-500 text-white px-4 py-2 rounded mt-2"
      >
        Post
      </button>
    </div>
  );
}